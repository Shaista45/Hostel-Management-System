#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
	const int MAX_ROOM = 50;
	using namespace std;
	class user {
	protected:
		string name;
		int id;
		string contact;
	public:
		virtual bool login() = 0;
	};
	class warden : public user {
		string password;
		string username;
	public:
		bool login() override {
			fstream ifile;
			ifile.open("warden.txt");
			cout << "enter your id: ";
			cin >> id;
			cout << "eneter password: ";
			cin >> password;
			string  p, a, c; int i;
			ifile >> a >> i >> c >> p;
				if (password == p && id == i)
				{
					cout << "logged in successfuly." << endl;
					system("cls");
					return true;
				}
				else {
					cout << "invalid id or password." << endl;
					return false;
				}
				ifile.close();
			}
		
		
	
		warden() {
			name = ""; id = 0; contact = ""; password = ""; username = "";
		}
		warden(string n, int i, string c, string p, string un) {
			fstream ifile;
			ifile.open("warden.txt", ios::app);
			name = n; id = i; contact = c; password = p; username = un;
			ifile << name << "\t" << id << "\t" << contact << "\t" << password << "\t" << username << endl;
			ifile.close();
		}
		void updatepassword() {
			fstream ifile;
			ifile.open("warden.txt");
			string n, c, p, un; int i;
			ifile >> n >> i >> c >> p >> un;
			ifile.close();
			removewardendata("warden.txt", n);
			cout << "enter new password:" << endl;
			string password;
			cin >> password;

			ifile.open("warden.txt");
			ifile << n << "\t" << i << "\t" << c << "\t" << password << "\t" << un << endl;
			ifile.close();
		}
		void removewardendata(const char* filename, const string& targetname) {
			ifstream inFile(filename);
			ofstream tempFile("temp.txt");

			string line;
			bool lineRemoved = false;

			while (getline(inFile, line)) {
				if (line.find(targetname) == string::npos) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}		inFile.close();
			tempFile.close();

			if (!lineRemoved) {
				cerr << "data for warden " << targetname << " not found." << endl;
				if (remove("temp.txt") != 0) {
					cerr << "Error deleting temporary file." << endl;
				}
				return;
			}

			if (remove(filename) != 0) {
				cerr << "Error deleting original file." << endl;
				return;
			}

			if (rename("temp.txt", filename) != 0) {
				cerr << "Error renaming temporary file." << endl;
				return;
			}
		}
		string getname() {
			return name;
		}
		int getid() {
			return id;
		}
		string getpassword() {
			return password;
		}
		string getcontact() {
			return contact;
		}
		string getusername() {
			return username;
		}
		void displaywarden() {
			fstream ifile;
			ifile.open("warden.txt");
			string n, c, p, un; int i;
			ifile >> n >> i >> c >> p >> un;
			cout << "warden info: \nname is: " << n << "\nid is: " << i << "\ncontact is: " << c << "\npassword is: " << p << "\nuser name is: " << un << endl;
			ifile.close();
		}
		void changewarden() {
			fstream ifile;
			ifile.open("warden.txt");
			string n;
			ifile >> n;
			ifile.close();
			removewardendata("warden.txt", n);
			ifile.open("warden.txt");
			cout << "enter new data: " << endl;
			string name, contact, password, username; int id;
			cout << "enter name: "; cin >> name;
			cout << "enter password: "; cin >> password;
			cout << "enter contact: "; cin >> contact;
			cout << "enter username: "; cin >> username;
			ifile << name << "\t" << id << "\t" << contact << "\t" << password << "\t" << username << endl;
			ifile.close();
		}
	};
	class staff :public user {
		string position;
		double salary;
	public:
		static int numstaff;
		bool login() override {
			fstream ifile;
			ifile.open("staff.txt");
			cout << "enter your name: "; cin >> name;
			cout << "enter your id: "; cin >> id;
			string n; int il;
			ifile >> n;
			for (int i = 0; i < numstaff; i++) {
				if (name == n) {
					ifile >> il;
					if (id == il) {
						cout << "logged in successfully." << endl;
						return true;
					}
					else {
						cout << "invalid name or id" << endl;
						return false;
					}
				}
				else {
					getline(ifile, n);
					ifile >> n;
					continue;
				}
			}
			cout << "invalid user name or id." << endl;
			return false;
			ifile.close();
		}

		void getstaffbyid() {
			int searchId;
			cout << "Enter Id: ";
			cin >> searchId;

			fstream ifile("staff.txt");
			if (!ifile.is_open()) {
				cout << "Error opening staff.txt" << endl;
				return;
			}

			string name, salary, contact, position;
			int id;
			bool found = false;

			while (ifile >> name >> id >> salary >> contact >> position) {
				if (id == searchId) {
					cout << "Name: " << name << "\n";
					cout << "ID: " << id << "\n";
					cout << "Salary: " << salary << "\n";
					cout << "Contact: " << contact << "\n";
					cout << "Position: " << position << "\n";
					found = true;
					break;
				}
			}

			if (!found) {
				cout << "Staff with ID " << searchId << " not found." << endl;
			}

			ifile.close();
		}

		void displayallstaff() {
			fstream ifile;
			ifile.open("staff.txt");
			string a;
			cout << "Name\tID\tSallary\tcontact\tPosition\n";
			cout << "***********************************************\n";
			for (int i = 0; i < numstaff; i++) {
				getline(ifile, a);
				cout << a << endl;
			}
		}
		void addstaffmember() {
			fstream infile;
			infile.open("staff.txt", ios::out | ios::app);
			cout << "enter staff data you wanted to add." << endl;
			cout << "enter staff name: " << endl;
			cin >> name;
			cout << "enter staff position: " << endl;
			cin >> position;
			cout << "enter staff id: " << endl;
			cin >> id;
			cout << "enter salary: " << endl;
			cin >> salary;
			cout << "enter staff contact: " << endl;
			cin >> contact;
			numstaff++;
			infile << name << "\t" << id << "\t" << salary << "\t" << contact << "\t" << position << endl;
			infile.close();

		}
		void removestaffmember() {
			cout << "enter staff name you wanted to remove: " << endl;
			cin >> name;
			removestaffdata("staff.txt", name);
		}
		void removestaffdata(const char* filename, const string& targetname) {
			ifstream inFile(filename);
			ofstream tempFile("temp.txt");

			string line;
			bool lineRemoved = false;

			while (getline(inFile, line)) {
				if (line.find(targetname) == string::npos) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}

			inFile.close();
			tempFile.close();

			if (!lineRemoved) {
				cerr << "data for staff " << targetname << " not found." << endl;
				if (remove("temp.txt") != 0) {
					cerr << "Error deleting temporary file." << endl;
				}
				return;
			}

			if (remove(filename) != 0) {
				cerr << "Error deleting original file." << endl;
				return;
			}

			if (rename("temp.txt", filename) != 0) {
				cerr << "Error renaming temporary file." << endl;
				return;
			}
			if (lineRemoved) {
				cout << "staff removed successfully." << endl;
				numstaff--;
			}
		}

	};
	int staff::numstaff = 9;
	class student :public user {
		string gender;
		int roomnumber;

	public:
		static int numstudent;
		bool login() override {
			fstream ifile;
			ifile.open("student.txt");
			cout << "enter your name: "; cin >> name;
			cout << "enter your id: "; cin >> id;
			string n; int i;
			ifile >> n;
			for (int i = 0; i < numstudent; i++) {
				if (name == n) 
				{
					ifile >> i;
					if (id == i) 
					{
						cout << "logged in successfully." << endl;
						return true;
					}
					else {
						cout << "invalid name or id" << endl;
						return false;
					}
				}
				else {
					getline(ifile, n);
					ifile >> n;
					continue;
				}
			}
			cout << "invalid  name or id." << endl;
			return false;
			ifile.close();
		}

		void addstudent() {
			fstream ifile;
			ifile.open("student.txt", ios::app);
			cout << "enter student data you wanted to add." << endl;
			cout << "enter name: "; cin >> name;
			cout << "enter id: "; cin >> id;
			cout << "enter contact: "; cin >> contact;
			cout << "enter gender: "; cin >> gender;
			cout << "enter room number: "; cin >> roomnumber;
			ifile << name << "\t" << id << "\t" << contact << "\t" << gender << "\t" << roomnumber << endl;
			ifile.close();
			numstudent++;
		}
		void removestudent() {
			cout << "enter student name to remove: " << endl;
			cin >> name;
			removestudentdata("student.txt", name);

		}
		static void removestudentdata(const char* filename, const string& targetname) {
			ifstream inFile(filename);
			ofstream tempFile("temp.txt");

			string line;
			bool lineRemoved = false;

			while (getline(inFile, line)) {
				if (line.find(targetname) == string::npos) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}

			inFile.close();
			tempFile.close();

			if (!lineRemoved) {
				cerr << "data for student " << targetname << " not found." << endl;
				if (remove("temp.txt") != 0) {
					cerr << "Error deleting temporary file." << endl;
					return;
				}
				return;
			}

			if (remove(filename) != 0) {
				cerr << "Error deleting original file." << endl;
				return;
			}

			if (rename("temp.txt", filename) != 0) {
				cerr << "Error renaming temporary file." << endl;
				return;
			}
			if (lineRemoved) {
				cout << "student removed successfully." << endl;
				numstudent--;
			}
		}
		void getstudentbyid() {
			int searchId;
			cout << "Enter Id: ";
			cin >> searchId;
			cout << "Information of Student with id"<< searchId<<"is:\n";
			fstream ifile("student.txt");
			if (!ifile) {
				cout << "Error opening file.\n";
				return;
			}

			string name, contact, gender;
			int id, roomnumber;
			bool found = false;

			for (int j = 0; j < numstudent; j++) {
				// Read in the same order as the file: Name ID Contact Gender RoomNumber
				ifile >> name >> id >> contact >> gender >> roomnumber;

				if (id == searchId) {
					cout << "Name: " << name
						<< "\nContact: " << contact
						<< "\nId: " << id
						<< "\nGender: " << gender
						<< "\nRoomnumber: " << roomnumber << endl;
					found = true;
					break;
				}
			}

			if (!found) {
				cout << "Student with id " << searchId << " not found" << endl;
			}
		}

		void displayallstudent() {
			fstream ifile;
			ifile.open("student.txt");
			string a;
			cout << "Name\tID\tContact\tGender\tRoom.NO\n";
			cout << "******************************************\n";
			for (int i = 0; i < numstudent; i++) {
				getline(ifile, a);
				cout << a << endl;
			}
		}
		int getid() {
			return id;
		}
		string getname() {
			return name;
		}
	};
	int student::numstudent = 9;
	class visitor :public user {
		string purpose;
		string checkindate, checkoutdate;
		static int numvisitor;
	public:
		bool login() override {
			fstream ifile;
			ifile.open("student.txt");
			cout << "enter students  name you wanted to meet: "; cin >> name;
			cout << "enter your id: "; cin >> id;
			string n; ifile >> n;
			for (int i = 0; i < student::numstudent; i++) {
				if (name == n) {
					cout << "logged in successfully." << endl;
					return true;
				}
				else {
					getline(ifile, n);
					ifile >> n;
				}
			}
			cout << "invalid  name entered." << endl;
			return false;
			ifile.close();
		}

		void addvisitor() {
			ofstream ifile("visitor.txt", ios::app);  // append mode
			if (!ifile.is_open()) {
				cout << "Error opening file for writing." << endl;
				return;
			}

			cout << "Enter visitor's data to add: " << endl;

			cin.ignore();  // flush newline left in buffer
			cout << "Enter name: ";
			getline(cin, name);

			cout << "Enter ID: ";
			cin >> id;

			cin.ignore();
			cout << "Enter purpose: ";
			getline(cin, purpose);

			cout << "Enter contact: ";
			getline(cin, contact);

			cout << "Enter check-in date: ";
			getline(cin, checkindate);

			cout << "Enter check-out date: ";
			getline(cin, checkoutdate);

			ifile << name << "\t" << id << "\t" << contact << "\t"
				<< purpose << "\t" << checkindate << "\t" << checkoutdate << endl;

			ifile.close();
			cout << "Visitor added successfully." << endl;
			numvisitor++;
		}

		void removevisitor() {
			cout << "enter visitor name to remove: "; cin >> name;
			removevisitordata("visitor.txt", name);
		}

		static void removevisitordata(const char* filename, const string& targetname) {
			ifstream inFile(filename);
			if (!inFile.is_open()) {
				cerr << "Error opening file: " << filename << endl;
				return;
			}

			ofstream tempFile("temp.txt");
			if (!tempFile.is_open()) {
				cerr << "Error creating temporary file." << endl;
				return;
			}

			string line;
			bool lineRemoved = false;

			while (getline(inFile, line)) {
				stringstream ss(line);
				string name;
				getline(ss, name, '\t');  // Extract the name field

				if (name != targetname) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}

			inFile.close();
			tempFile.close();

			if (!lineRemoved) {
				cerr << "Data for visitor \"" << targetname << "\" not found." << endl;
				remove("temp.txt");
				return;
			}

			if (remove(filename) != 0) {
				perror("Error deleting original file");
				return;
			}

			if (rename("temp.txt", filename) != 0) {
				perror("Error renaming temporary file");
				return;
			}

			cout << "Visitor removed successfully." << endl;
			numvisitor--;  // Make sure numvisitor is valid
		}
		void displayvisitor() {
			fstream ifile("visitor.txt");
			if (!ifile.is_open()) {
				cout << "Error opening visitor.txt" << endl;
				return;
			}

			string line;
			cout << "Name\tID\tContact\tPurpose\tCheck_in_Date\tCheck_out_Date\n";
			cout << "*****************************************************************************\n";

			while (getline(ifile, line)) {
				cout << line << endl;
			}

			ifile.close();
		}

	};
	int visitor::numvisitor = 9;
	class room {
		int roomnumber;
		int capacity;
		string status;

	public:
		static int numrooms;
		void addroom() {
			int a; string b;
			fstream ifile;
			ifile.open("room.txt", ios::app);
			if (numrooms < MAX_ROOM) {
				cout << "enter room data you wanted to add." << endl;
				cout << "enter room number: "; cin >> roomnumber;
				cout << "enter capacity: "; cin >> capacity;
				status = "available";
				ifile << roomnumber << "\t" << capacity << "\t" << status << endl;
				cout << "room added successfully." << endl;
				numrooms++;
			}
			else {
				cout << "cannot add room." << endl;
			}
			ifile.close();
		}
		void removeroomdata(const string& filename, int valueToRemove) {
			ifstream inputFile(filename);

			ofstream tempFile("temp.txt");

			string line;
			bool lineRemoved = false;

			while (getline(inputFile, line)) {
				stringstream ss;
				ss << valueToRemove;
				string stringValue = ss.str();

				if (line.find(stringValue) == string::npos) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}

			inputFile.close();
			tempFile.close();

			if (!lineRemoved) {
				cerr << "Value not found in the file." << endl;
				remove("temp.txt");
				return;
			}

			if (remove(filename.c_str()) != 0) {
				cerr << "Error deleting original file." << endl;
				return;
			}

			if (rename("temp.txt", filename.c_str()) != 0) {
				cerr << "Error renaming temporary file." << endl;
				return;
			}
		}
		void removeroom() {
			cout << "enter room number you wanted to remove: "; cin >> roomnumber;
			removeroomdata("room.txt", roomnumber);

		}
		void allocateroom() {
			fstream ifile, infile;
			infile.open("room.txt");
			ifile.open("allocate.txt");

			string name;
			int capacity = 0, a, b, c;
			cout << "enter room number you wanted to allocate: "; cin >> roomnumber;
			cout << "enter student name whom you wanted to allocate this room: "; cin >> name;
			infile >> a; ifile >> c;
			string n;
			for (int i = 0; i < numrooms; i++) {
				if (a == roomnumber) {
					infile >> b;
					for (int j = 0; j < student::numstudent; j++) {
						if (c == roomnumber) {
							capacity++;
							getline(ifile, n);
							ifile >> c;

						}
						else {
							getline(ifile, n);
							ifile >> c;

						}
					}
					if (capacity < b || capacity == 0) {
						ifile << roomnumber << "\tallocated to: " << name << endl;
						cout << "room allocated successfully." << endl;
						student::numstudent++;
						break;
					}
					else {
						cout << "no space remaining in this room." << endl;
						break;
					}
				}
				else {
					getline(infile, n);
					ifile >> a;
					continue;
				}
			}
			ifile.close(); infile.close();

		}
		void dellocateroom() {
			fstream ifile;
			string name;
			ifile.open("allocation.txt");
			cout << "enter students name  to dellocate: "; cin >> name ;
			ifile.close();
			student::removestudentdata("allocation.txt", name);

		}
		void displayrooms() {
			fstream ifile;
			ifile.open("room.txt");
			string a;
			cout << "Room NO\tCapacity Status\n";
			cout << "**************************************\n";
			for (int i = 0; i < numrooms; i++) {
				getline(ifile, a);
				cout << a << endl;
			}
		}
	};
	class meal {
		const int meals_a_day = 2;
		string meal1;
		string meal2;
	public:
		void displaymealsbyday() {
			fstream ifile;
			ifile.open("meals.txt");
			string day;
			string a, b;
			cout << "enter the day whom meals you wanted to see: "; cin >> day;
			ifile >> a;
			for (int i = 0; i < 7; i++) {
				if (a == day) {
					getline(ifile, b);
					cout << a << b;
					return;
				}
				else {
					getline(ifile, b);
					ifile >> a;
				}
			}
			cout << "no data found." << endl;
		}
		void updatemeals() {
			fstream ifile;
			ifile.open("meals.txt");
			string day;
			string a, b;
			cout << "enter the day whom meals you wanted to updated: "; cin >> day;
			ifile >> a;
			for (int i = 0; i < 7; i++) {
				if (a == day) {
					break;
				}
				else {
					getline(ifile, b);
					ifile >> a;
				}
			}
			ifile.close();
			if (a == day) {
				removemealdata("meals.txt", day);
			}
			else {
				cout << "data not found." << endl;
				return;
			}
			ifile.open("meals.txt");
			cout << "enter updated meal data for " << day << endl;
			cout << "enter meal 1: "; cin >> meal1;
			cout << "enter meal 2: "; cin >> meal2;
			ifile << day << "\tmeal1: " << meal1 << "\t200" << "\tmeal2: " << meal2 << "\t250" << endl;
			ifile.close();

		}
		static void removemealdata(const char* filename, const string& targetname) {
			ifstream inFile(filename);
			ofstream tempFile("temp.txt");

			string line;
			bool lineRemoved = false;

			while (getline(inFile, line)) {
				if (line.find(targetname) == string::npos) {
					tempFile << line << endl;
				}
				else {
					lineRemoved = true;
				}
			}

			inFile.close();
			tempFile.close();

			if (!lineRemoved) {
				if (remove("temp.txt") != 0) {

				}
				return;
			}

			if (remove(filename) != 0) {
				return;
			}

			if (rename("temp.txt", filename) != 0) {
				return;
			}

		}
		void displaymeals() {
			fstream ifile;
			ifile.open("meals.txt");
			string a;
			cout << "";
			cout<<"***********************************************************\n";
			for (int i = 0; i < 7; i++) {
				getline(ifile, a);
				cout << a << endl;
			}
		}
	};

	class mess {

	public:
		static int numattendence;
		void markstudentattendence() {
			string name, day, time;
			cout << "enter student name: "; cin >> name;
			cout << "enter today's day: "; cin >> day;
			cout << "enter meal time(meal1 for lunch and meal2 for dinner: "; cin >> time;
			fstream ifile;
			ifile.open("attendence.txt", ios::app | ios::out);
			ifile << name << "\t" << day << "\t" << time<<endl;
			ifile.close();
			numattendence++;
		}
		void displayattendence() {
			fstream ifile;
			ifile.open("attendence.txt");
			string a;
			cout << "Name\tDate\tMeal\n";
			cout << "**************************************\n";
			for (int i = 0; i < numattendence; i++) {
				getline(ifile, a);
				cout << a << endl;
			}
		}
	};
	int mess::numattendence = 9;
	class revenue {
	public:
		void calculatestudentbill() {
			fstream ifile, infile;
			ifile.open("attendence.txt"), infile.open("bill.txt");
			string a, b, c, name;
			double ab = 0;
			ifile >> a;
			cout << "enter students name: "; cin >> name;
			for (int i = 0; i < mess::numattendence; i++) {
				if (a == name) {
					ifile >> b >> c;
					if (c == "meal1") {
						ab += 200;
					}
					else if (c == "meal2") {
						ab += 250;
					}
					ifile >> a;
				}
				else {
					getline(ifile, b);
					ifile >> a;
					continue;
				}
			}
			cout << "your bill is: " << ab << endl;
			infile << ab << endl;
			ifile.close(), infile.close();
		}
		void calculatestaffsalary() {
			fstream ifile;
			ifile.open("staff.txt");
			string name, a; int b; double c;
			cout << "enter staff name: "; cin >> name;
			ifile >> a;
			for (int i = 0; i < staff::numstaff; i++) {
				if (a == name) {
					ifile >> b >> c;
					cout << "monthly salary of " << name << " is " << c << endl;
					double bonus = c * 0.2;
					cout << "bonus in a year is: " << bonus << endl;
					c *= 12;
					c += bonus;
					cout << "yearly salary with bonus is: " << c << endl;
					return;
				}
				else {
					getline(ifile, a);
					ifile >> a;
				}
			}
			cout << "data not found." << endl;
		}
	};
	int room::numrooms = 9;
	class hostel {
		staff staf;
		warden wardens;
		student students;
		visitor v;
		meal m;
		mess me;
		room rooms;
		revenue revenues;
	public:
		void addroom() {
			rooms.addroom();
		}
		void removeroom() {
			rooms.removeroom();
		}
		void allocateroom() {
			rooms.allocateroom();
		}
		void delocateroom() {
			rooms.dellocateroom();
		}
		void displayroom() {
			rooms.displayrooms();
		}
		void addstudent() {
			students.addstudent();
		}
		void removestudent() {
			students.removestudent();
		}
		void searchstudentbyid() {
			students.getstudentbyid();
		}
		void displaystudents() {
			students.displayallstudent();
		}
		void addstaffmember() {
			staf.addstaffmember();
		}
		void removestaff() {
			staf.removestaffmember();
		}
		void searchstaffbyid() {
			staf.getstaffbyid();
		}
		void displaystaff() {
			staf.displayallstaff();
		}
		void displaymealbyday() {
			m.displaymealsbyday();
		}
		void displaymeals() {
			m.displaymeals();
		}
		void updatemeals() {
			m.updatemeals();
		}
		void calculatestudentbill() {
			revenues.calculatestudentbill();
		}
		void calculatestaffsalary() {
			revenues.calculatestaffsalary();
		}
		void markstudentattendenceformeal() {
			me.markstudentattendence();
		}
		void displayallstudentsmessttendence() {
			me.displayattendence();
		}
		void addvisitor() {
			v.addvisitor();
		}
		void removevisitor() {
			v.removevisitor();
		}
		void displayvisitors() {
			v.displayvisitor();
		}
		void updatepassworddata() {
			wardens.updatepassword();
		}
		void displaywarden() {
			wardens.displaywarden();
		}
		void changewarden() {
			wardens.changewarden();
		}
		void studentmenu() {
			int ch;
			do {
				
				cout << "1. Display meal" << endl;
				cout << "2. Display meal by day" << endl;
				cout << "3. mark attendance" << endl;
				cout << "4. view attandence" << endl;
				cout << "5. Calculate student bill" << endl;
				cout << "6. Exit." << endl;
				cin >> ch;

				switch (ch) {
				case 1:
					system("cls");
					displaymeals();
					break;
				case 2:
					system("cls");
					displaymealbyday();
					break;
				case 3:
					system("cls");
					markstudentattendenceformeal();
					break;
				case 4:
					system("cls");
					displayallstudentsmessttendence();
					break;
				case 5:
					system("cls");
					calculatestudentbill();
				break;
				case 6:
					cout << "logging out." << endl;
					break;
				default:
					cout << "Invalid input./nPlease try again.";
					break;
				}

			}while (ch != 6);
	}
		void visitormenu()
		{
			int ch;
          do{
			cout << "1. add visiting date" << endl;
			cout << "2. remove visiting appoinment" << endl;
			cout << "3.check your visiting dates" << endl;
			cout << "4. exit" << endl;
			cin >> ch;
			
				switch (ch) {
				case 1:
					system("cls");
					v.addvisitor();
					break;
				case 2:
					system("cls");
					v.removevisitor();
					break;
				case 3:
					system("cls");
					v.displayvisitor();
					break;
				case 4:
					cout << "logging out." << endl;
					break;
				default:
					cout << "invalid choice" << endl;
					break;
				}
		 } while (ch != 4);

		}
		void wardenmenu()
		{
			
			int ch;
			do {

				cout << "1. Add room" << endl;
				cout << "2. Remove room" << endl;
				cout << "3. display rooms" << endl;
				cout << "4. add student" << endl;
				cout << "5. remove student" << endl;
				cout << "6. display students" << endl;
				cout << "7. view attendance record" << endl;
				cout << "8. view mess details" << endl;
				cout << "9. search student" << endl;
				cout << "10. Search staff" << endl;
				cout << "11. Calculate student Bill" << endl;
				cout << "12. Add visitor" << endl;
				cout << "13. Remove visitor" << endl;
				cout << "14. Display visitor" << endl;
				cout << "15. Display meal by day" << endl;
				cout << "16. Add staff" << endl;
				cout << "17. Remove staff" << endl;
				cout << "18. Update Password" << endl;
				cout << "19. Update meals" << endl;
				cout << "20. calculate staff salary" << endl;
				cout << "21. Allocate room" << endl;
				cout << "22. De allocate room" << endl;
				cout << "23. Display Warden information" << endl;
				cout << "24. Display staff Data" << endl;
				cout << "25. Exit" << endl;
				cin >> ch;
				switch (ch) {
				case 1:
					system("cls");
					addroom();
					break;
				case 2:
					system("cls");
					removeroom();
					break;
				case 3:
					system("cls");
					displayroom();
					break;
				case 4:
					system("cls");
					addstudent();
					break;
				case 5:
					system("cls");
					removestudent();
					break;
				case 6:
					system("cls");
					displaystudents();
					break;
				case 7:
					system("cls");
					displayallstudentsmessttendence();
					break;
				case 8:
					system("cls");
					displaymeals();
					break;
				case 9:
					system("cls");
					searchstudentbyid();
					break;
				case 10:
					system("cls");
					searchstaffbyid();
					break;
				case 11:
					system("cls");
					calculatestudentbill();
					break;
				case 12:
					system("cls");
					addvisitor();
					break;
				case 13:
					system("cls");
					removevisitor();
					break;
				case 14:
					system("cls");
					displayvisitors();
					break;
				case 15:
					system("cls");
					displaymealbyday();
					break;
				case 16:
					system("cls");
					addstaffmember();
					break;
				case 17:
					system("cls");
					removestaff();
					break;
				case 18:
					system("cls");
					updatepassworddata();
					break;
				case 19:
					system("cls");
					updatemeals();
					break;
				case 20:
					system("cls");
					calculatestaffsalary();
					break;
				case 21:
					system("cls");
					allocateroom();
					break;
				case 22:
					system("cls");
					delocateroom();
					break;
				case 23:
					system("cls");
					displaywarden();
					break;
				case 24:
					system("cls");
					staf.displayallstaff();
				case 25:
					cout << "logging out." << endl;
					break;
				default:
					cout << "Invalid input./nPlease try again.";
					break;
				}
			} while (ch != 24);

		}
	};
	
	int main() {
		hostel h;
		warden w;
		student s;
		visitor v;
		int c;
		int i;
		int choice;
		int choices;
		int Choice;
		cout << "\n\n\t\t\t";
		for (i = 0; i < 59; i++)
		{
			cout << "*";
		}
		cout << "\n";
		cout << "\t\t\t*\t\t\t\t\t\t\t  *\n";
		cout << "\t\t\t*\t\t\tWELCOME\t\t\t\t  *\n";
		cout << "\t\t\t*\t\tHostel Management System\t\t  *\n";
		cout << "\t\t\t*\t\t\t\t\t\t\t  *\n";
		cout << "\t\t\t";
		for (i = 0; i < 59; i++)
		{
			cout << "*";
		}
		cout << "\n";
		system("pause");
		system("cls");
		do {
			cout << "\n\n\t\t\t\t\t1. warden" << endl;
			cout << "\t\t\t\t\t2. student" << endl;
			cout << "\t\t\t\t\t3. visitor" << endl;
			cout << "\t\t\t\t\t4. Exit." << endl;
			cout << "\t\t\t\t\tEnter your choice:" << endl;
			cin >> c;

			switch (c)
			{
			case 1:
				if (w.login()) {
					h.wardenmenu();
				}
				break;

			case 2:
				if (s.login()) {
					h.studentmenu();
			}
				break;
		case 3:
			if (v.login()) {
				h.visitormenu();
					
					break;

				}
			default:
				cout << "invalid choice" << endl;
				break;
			}
		} while (c != 4);
}